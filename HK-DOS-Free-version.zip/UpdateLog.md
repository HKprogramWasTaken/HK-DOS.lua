# HKDOS
Update Log
Version 0.1.7

------------------------------------------------------------


Updated Directory List with the new programs added since 0.1.6

Fixed new commands in Notepad:

----
input-date: UTC (Gets UTC Time)

clear-notepad (Creates new text document/Erases Document)
----

BUG FIXES:
----
BSoD Module Caused a Repeated message when every program existed. Removed the Repeat Function. Will fix this later on with 0.1.8

----

------------------------------------------------------------