# H K  D O S 

Made by HxKprogram

Created in Lua 5.1.5

This is a project i have been working on for 13 days now, And i am really happy by the results

It is not officially done yet, I will be working on this project for a long time as i feel to continue on It

This is only version 0.1.6, More stuff is coming...

So the start of this project was when i got interested in old computer and Operating systems, Like MS-DOS And windows 1.01. 

I was really interested in like old dos viruses beacuse They aren't like todays viruses

I already had programmed in 2 years now, I was ready to step up things. So i decided to create this DOS Operating System. I named it HK-DOS Similar to MS-DOS.

I already knew some programming launguages as html,css,js And lua, But beacuse lua is a console programming launguage, I decided to pick lua

This Project Is a virtualization of a 1980's
DOS Computer, But with my own dos Operating system

# OTHER STUFF:

This project does not have a copyright license.

You chould like take some ideas from this, It is absolutely okay, But do not take my Whole work and take it as yours.



Date created:
2021-01-14

Country created in: Sweden, Kungsbacka

Version: 0.1.7

